!function(t, e) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = "undefined" != typeof globalThis ? globalThis : t || self).mdtoast = e()
}(this, function() {
    "use strict";
    function i(t, e) {
        for (var o = 0; o < e.length; o++) {
            var n = e[o];
            n.enumerable = n.enumerable || !1,
            n.configurable = !0,
            "value"in n && (n.writable = !0),
            Object.defineProperty(t, n.key, n)
        }
    }
    var a = {
        defaults: {
            init: !1,
            duration: 5e3,
            type: "default",
            modal: !1,
            interaction: !1,
            interactionTimeout: null,
            actionText: "OK",
            action: function() {
                this.hide()
            },
            callbacks: {}
        },
        toastOpenClass: "mdtoast--open",
        toastModalClass: "mdtoast--modal"
    };
    function s(t) {
        var o = {}
          , n = !1
          , e = 0
          , i = arguments.length;
        "[object Boolean]" === Object.prototype.toString.call(t) && (n = t,
        e++);
        for (; e < i; e++)
            !function(t) {
                for (var e in t)
                    Object.prototype.hasOwnProperty.call(t, e) && (n && "[object Object]" === Object.prototype.toString.call(t[e]) ? o[e] = s(!0, o[e], t[e]) : o[e] = t[e])
            }(arguments[e]);
        return o
    }
    function c(t, e, o, n) {
        t = document.createElement(t);
        return t.className = e,
        void 0 !== o && (t[n ? "innerHTML" : "innerText"] = o),
        t
    }
    function l() {
        function t(t) {
            t.target.matches(".mdt-action") && ("click" === t.type || "keypress" === t.type && 13 === t.keyCode) && n.action && n.action.call(o, t)
        }
        var e, o = this, n = o.options;
        o.docFrag = document.createDocumentFragment(),
        o.toast = c("div", "mdtoast mdt--load"),
        o.toast.tabIndex = 0,
        o.docFrag.appendChild(o.toast),
        "default" !== n.type && o.toast.classList.add("mdt--" + n.type),
        e = c("div", "mdt-message", o.message, !0),
        o.toast.appendChild(e),
        e = c("span", "mdt-action"),
        n.interaction && (e.innerText = n.actionText,
        e.tabIndex = 0,
        o.toast.classList.add("mdt--interactive"),
        o.toast.appendChild(e)),
        o.toast.addEventListener("click", t, !1),
        o.toast.addEventListener("keypress", t, !1),
        (o.toast.mdtoast = o).options.init || o.show()
    }
    function r(t) {
        var e = this
          , o = document.body
          , n = e.options.callbacks;
        o.appendChild(e.docFrag),
        setTimeout(function() {
            e.toast.classList.remove("mdt--load"),
            setTimeout(function() {
                n && n.shown && n.shown.call(e),
                t && "function" == typeof t && t.call(e)
            }, e.animateTime),
            e.options.interaction ? e.options.interactionTimeout && (e.timeout = setTimeout(function() {
                e.hide()
            }, e.options.interactionTimeout)) : e.options.duration && (e.timeout = setTimeout(function() {
                e.hide()
            }, e.options.duration)),
            o.classList.add(a.toastOpenClass),
            e.options.modal && o.classList.add(a.toastModalClass)
        }, 15)
    }
    var e = function() {
        function n(t, e) {
            !function(t, e) {
                if (!(t instanceof e))
                    throw new TypeError("Cannot call a class as a function")
            }(this, n);
            var o = arguments;
            this.animateTime = 230,
            this.message = o[0],
            this.options = s(!0, a.defaults, o[1]),
            this.timeout = null,
            this.options.init || l.call(this)
        }
        var t, e, o;
        return t = n,
        (e = [{
            key: "show",
            value: function(t) {
                var e = this
                  , o = document.getElementsByClassName("mdtoast");
                if (!document.body.contains(e.toast))
                    if (e.options.init && l.apply(e),
                    0 < o.length)
                        for (var n = o.length - 1; 0 <= n; n--)
                            o[n].mdtoast.hide(function() {
                                n < 0 && r.call(e, t)
                            });
                    else
                        r.call(e, t)
            }
        }, {
            key: "hide",
            value: function(t) {
                var e = this
                  , o = e.options.callbacks
                  , n = document.body;
                clearTimeout(e.timeout),
                e.toast.classList.add("mdt--load"),
                n.classList.remove(a.toastOpenClass),
                n.classList.remove(a.toastModalClass),
                setTimeout(function() {
                    n.removeChild(e.toast),
                    o && o.hidden && o.hidden.call(e),
                    t && "function" == typeof t && t.call(e)
                }, e.animateTime)
            }
        }]) && i(t.prototype, e),
        o && i(t, o),
        n
    }();
    function o(t) {
        return new e(t,1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {})
    }
    return o.info = function(t) {
        return o(t, s(!0, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, {
            type: "info"
        }))
    }
    ,
    o.error = function(t) {
        return o(t, s(!0, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, {
            type: "error"
        }))
    }
    ,
    o.warning = function(t) {
        return o(t, s(!0, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, {
            type: "warning"
        }))
    }
    ,
    o.success = function(t) {
        return o(t, s(!0, 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, {
            type: "success"
        }))
    }
    ,
    Object.defineProperties(o, {
        INFO: {
            value: "info"
        },
        ERROR: {
            value: "error"
        },
        WARNING: {
            value: "warning"
        },
        SUCCESS: {
            value: "success"
        }
    }),
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.matchesSelector || Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector || Element.prototype.oMatchesSelector || Element.prototype.webkitMatchesSelector || function(t) {
        for (var e = (this.document || this.ownerDocument).querySelectorAll(t), o = e.length; 0 <= --o && e.item(o) !== this; )
            ;
        return -1 < o
    }
    ),
    o
});
