"use strict"
exports.SearchTypes = {
    ANY: "CAA%3D",
    CHANNEL: "EgIQAg%3D%3D",
    LIVE: "EgJAAQ%3D%3D",
    MOVIE: "EgIQBA%3D%3D",
    PLAYLIST: "EgIQAw%3D%3D",
    VIDEO: "EgIQAQ%3D%3D"
};
exports.YouTubeURL = new URL('https://www.youtube.com/results');
