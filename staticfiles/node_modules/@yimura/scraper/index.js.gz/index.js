"use strict"
const Constants = require('./src/Constants.js');
const Scraper = require('./src/Scraper.js');

module.exports = {
    Constants,
    default: Scraper,
    Scraper
};
